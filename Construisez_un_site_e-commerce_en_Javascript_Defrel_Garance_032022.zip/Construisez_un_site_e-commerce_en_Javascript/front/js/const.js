//Déclaration de la variable permettant de récupérer les données de tous les produits
const BASE_URL = "http://localhost:3000/api/products";
//Déclaration de la variable permettant de récupérer toutes les données pour les mettres dans le panier
const CART_KEY = "cart";
